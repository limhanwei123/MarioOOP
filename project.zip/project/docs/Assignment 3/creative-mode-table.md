# Requirement 4

**Title**:
_Bowyer_

**Description**:
_An enemy that has the ability to shoot out fire arrows to damage players but can't shoot through walls.
<br> Has health of 500, damages players with 30 damage and when reset it goes back to its spawn location._

**Explanation why it adheres to SOLID principles** (WHY):
It adheres to the open-closed principle, since we are making another enemy by extending more from the enemies class without modifying
the code of from the enemies class.
-

| Requirements                                                                                                                 | Features (HOW) / Your Approach / Answer                                                                                                                                                                                                          |
|------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Must use at least two (2) classes from the engine package                                                                    | We used two classes from engine package. Bowyer class extends from enemies class with extends from actor. FireBowAction is extended from Action class. FireBow extends from WeaponItem class                                                     |
| Must use/re-use at least one(1) existing feature (either from assignment 2 and/or fixed requirements from assignment 3)      | We re-use enemies class from assignment 2 by extending enemies class with Bowyer class. We have also used the fire feature that Bowser has from assignment 3 requirement 2. We have also used the Attack, Wander and Follow Behavior for Bowyer. |
| Must use existing or create new abstractions (e.g., abstract or interface, apart from the engine code)                       | We used existing abstractions from enemies class. Bowyer class is extended from enemies class.                                                                                                                                                   |
| Must use existing or create new capabilities                                                                                 | We have created a new RANGED_ATTACK capability so we can indicate that Bowyer can use ranged weapons which is the FireBow.                                                                                                                       |

---

# Requirement 5

**Title**:
_Yoshi, LETS GO!!_

**Description**:
_An adventurer partner that follows you and provides you buffs. It follows you to the next map.
<br> It heals you by 5 hp or adds 1 damage to you attacks when it is beside you.
<br> It won't be attacked by enemies, amd it can fly through wall or tree._

**Explanation why it adheres to SOLID principles** (WHY):
It adheres single responsibility principle, as Yoshi class only has 1 responsibility to give buffs to player.
It also adheres open-closed principle, SupportBehavior extends from Behavior abstract class without modifying class itself.
-

| Requirements                                                                                                            | Features (HOW) / Your Approach / Answer                                                                                                                                    |
|-------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Must use at least two (2) classes from the engine package                                                               | We used two classes from engine package. Yoshi class extends from Actor. SupportAction class extends from Action.                                                          |
| Must use/re-use at least one(1) existing feature (either from assignment 2 and/or fixed requirements from assignment 3) | We used follow behavior for Yoshi. We have also used add damage feature we have done from requirement 3 assignment 3 from fountain, by adding buffs for player from Yoshi. |
| Must use existing or create new abstractions (e.g., abstract or interface, apart from the engine code)                  | We used existing abstractions, behavior abstraction. We have SupportBehavior extending from behavior abstract class.                                                       |
| Must use existing or create new capabilities                                                                            | We created ALLIES capability for Yoshi to travel through tall terrains easily. We added CAN_ENTER_FLOOR capability for Yoshi as well.                                      |
