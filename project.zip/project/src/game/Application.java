package game;

import java.util.Arrays;
import java.util.List;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.FancyGroundFactory;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.positions.World;
import game.enemies.Bowser;
import game.enemies.Koopa;
import game.enemies.Bowyer;
import game.enums.PlayerStatus;
import game.npcs.PrincessPeach;
import game.npcs.Toad;
import game.terrains.*;

/**
 * The main class for the Mario World game.
 *
 */
public class Application {

	public static void main(String[] args) {

		World world = new World(new Display());

		FancyGroundFactory groundFactory = new FancyGroundFactory(new Dirt(), new Wall(), new Floor(), new Sprout(), new Sapling(), new Mature(), new HealthFountain(), new PowerFountain());

		FancyGroundFactory groundFactory1 = new FancyGroundFactory(new Dirt(), new Wall(), new Floor(), new Lava());

		List<String> forest = Arrays.asList(
			"..........................................##..........+.........................",
			"............+............+..................#...................................",
			"............................................#...................................",
			".............................................##......................+..........",
			"...............................................#................................",
			"................................................#...............................",
			".................+.......T........................#...............T.............",
			".................................................##.............................",
			"................................................##..............................",
			".........+..............................+#____####.................+............",
			"....................T..................+#_____###++.............................",
			"...................................T...+#______###..............................",
			"...................................T....+#__HA_###..............................",
			"........T...............+........................##.............+...............",
			"...................................................#............................",
			"....................................................#...........................",
			"...................+...........T.....................#..........................",
			"......................................................#.........................",
			".......................................................##......................_");

		List<String> lavaZone = Arrays.asList(
			"________#.........................LLLLLLLL......................LLLLLLLL",
			"________#.........................LLL..LLL...............LLLL...LLLLLLLL",
			"________#......##......LL.........LLLLLLLL...........LLLLLL.....LLLLLLLL",
			"_________..............LL............LLLLLL.....................LLLLLLLL",
			"#########...............................LLL.....................LLLLLLLL",
			"L.................................#.......LLL...........................",
			"L#..............................#.......LLL.............................",
			"L#...............................#....LLL.......................########",
			"LL#.............................##..............................#.......",
			"LLL#.............................................##.............#.......",
			"LL................................................#.....................",
			"LLLLLLLLL..........................LL............#..............#.......",
			"LLLLLLLLL....LLL..................LL............#...............#.......",
			"LLLLLLLLL........LLL...............LL...........................########",
			"LLLLLLLLL.........LLLLLLL.........LL....................................",
			"LLLLLLLLL...LLL.................LLL.....................................");


		GameMap gameMap = new GameMap(groundFactory, forest);
		world.addGameMap(gameMap);

		GameMap gameMap1 = new GameMap(groundFactory1, lavaZone);
		world.addGameMap(gameMap1);

		// FOREST
		Actor mario = new Player("Mario", 'm', 100000);
		Toad toad = new Toad("Toad", 'O', 10000);
		world.addPlayer(mario, gameMap.at(42, 10));
		gameMap.addActor(toad, gameMap.at(43,10));

		gameMap.addActor(new Yoshi(), gameMap.at(41, 10));

		Location goToLavaZone = gameMap1.at(0, 0);
		Location goToForest = gameMap.at(42,8);

		gameMap.at(42, 8).setGround(new WarpPipe(goToLavaZone, "to Lava Zone"));
		gameMap.at(43, 8).setGround(new WarpPipe(goToLavaZone, "to Lava Zone"));

		gameMap1.at(0, 0).setGround(new WarpPipe(goToForest, "to Forest"));

		Bowser bowser = new Bowser();
		PrincessPeach princessPeach = new PrincessPeach();

		gameMap1.addActor(bowser,gameMap1.at(10,10));
		gameMap1.addActor(princessPeach,gameMap1.at(11,10));

		Bowyer bowyer = new Bowyer(gameMap1.at(10,5));
		gameMap1.addActor(bowyer,gameMap1.at(10,5));

		mario.addCapability(PlayerStatus.POWER);

		// LAVAZONE

		world.run();

	}
}
