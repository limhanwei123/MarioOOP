package game;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.behaviours.FollowBehaviour;
import game.behaviours.SupportBehavior;
import game.enums.PlayerStatus;
import game.interfaces.Behaviour;
import game.managers.PlayerManager;

import java.util.HashMap;
import java.util.Map;

/**
 * <h1>Yoshi</h1>
 * A class that represents Yoshi.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 20/5/2022
 *  @see Actor
 */
public class Yoshi extends Actor {
    /**
     * Yoshi's Behaviour
     */
    private final Map<Integer, Behaviour> behaviours = new HashMap<>();

    /**
     * HP that can be heal by yoshi
     */
    private int heal = 5;

    /**
     * Damage that can be increase by yoshi
     */
    private int damage = 1;

    /**
     * Constructor.
     */
    public Yoshi() {
        super("Yoshi", 'w', 100);
        this.addCapability(PlayerStatus.ALLIES);
        this.addCapability(PlayerStatus.CAN_ENTER_FLOOR);
    }

    /**
     * Method to let Yoshi know what to do in every turn
     *
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return Action that be done by Yoshi
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {

        // Get current location
        Location location = map.locationOf(this);
        for (Exit exit : location.getExits()) {
            // Get location around it
            Location destination = exit.getDestination();
            // If a player is around yoshi then follow and support the player
            if (destination.containsAnActor()){
                Actor actor = destination.getActor();
                if (actor.hasCapability(PlayerStatus.PLAYER)){
                    Player player = PlayerManager.getInstance().getPlayer(actor);
                    this.behaviours.put(5, new FollowBehaviour(player));
                    this.behaviours.put(10, new SupportBehavior(player, heal, damage));
                    player.setYoshi(this);
                }
            }
        }

        // Get the action that will be done in the round
        for(Behaviour Behaviour : behaviours.values()) {
            Action action = Behaviour.getAction(this, map);
            if (action != null)
                return action;
        }
        // else return do nothing action
        return new DoNothingAction();
    }


}
