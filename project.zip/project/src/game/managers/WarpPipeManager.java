package game.managers;

import edu.monash.fit2099.engine.positions.Location;
import game.items.MagicalItem;
import game.terrains.WarpPipe;

import java.util.ArrayList;

/**
 * <h1>WarpPipeManager</h1>
 * A class that use to manage the warp pipes.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 22/5/2022
 *  @see WarpPipe
 */
public class WarpPipeManager {
    /**
     * A list of warp pipe instances
     */
    private ArrayList<WarpPipe> warpPipeList;
    private static WarpPipeManager instance;

    /**
     * Get the singleton instance of WarpPipeManager
     * @return WarpPipeManager singleton instance
     */
    public static WarpPipeManager getInstance(){
        if (instance == null) {
            instance = new WarpPipeManager();
        }
        return instance;
    }
    /**
     * Private constructor that initialise a new warpPipeList as the class attribute
     */
    private WarpPipeManager(){
        warpPipeList = new ArrayList<>();
    }

    /**
     * Add a WarpPipe to the warpPipeList
     * @param warpPipe a WarpPipe
     */
    public void appendWarpPipe(WarpPipe warpPipe) {
        this.warpPipeList.add(warpPipe);
    }

    /**
     * Getter for the ArrayList warpPipeList
     * @return ArrayList MagicalItemList
     */
    public ArrayList<WarpPipe> getWarpPipeList() {
        return new ArrayList<WarpPipe>(this.warpPipeList);
    }

    /**
     * Getter for the WarpPipe if the location contains a WarpPipe
     *
     * @param location a location in the game map
     * @return a WarpPipe if the location contains a WarpPipe,else null
     */
    public WarpPipe getWarpPipe(Location location){
        WarpPipe returnItem = null;
        for (int i =0; i<warpPipeList.size();i++){
            if (warpPipeList.get(i)==location.getGround()){
                returnItem = warpPipeList.get(i);
            }
        }
        return returnItem;
    }
}
