package game.managers;

import edu.monash.fit2099.engine.actors.Actor;
import game.Player;

import java.util.ArrayList;

/**
 * <h1>PlayerManager</h1>
 * A class that use to manage the players.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Player
 */
public class PlayerManager {
    /**
     * A list of player instances (any player is created is added in)
     */
    private ArrayList<Player> players;

    /**
     * A singleton player manager instance
     */
    private static PlayerManager instance;

    /**
     * Private constructor that initialise a new PlayerList, players as the class attribute
     */
    private PlayerManager() {
        players = new ArrayList<>();
    }

    /**
     * Get the singleton instance of player manager
     * @return PlayerManager singleton instance
     */
    public static PlayerManager getInstance() {
        if (instance == null) {
            instance = new PlayerManager();
        }
        return instance;
    }

    /**
     * Add a player to the PlayerList
     * @param player a player
     */
    public void appendPlayer(Player player) {
        this.players.add(player);
    }

    /**
     * Getter for the ArrayList PlayerList
     * @return ArrayList PlayerList
     */
    public ArrayList<Player> getPlayers() {
        return new ArrayList<Player>(this.players);
    }

    /**
     * Getter for the player if the actor is a player
     *
     * @param actor the current actor
     * @return the current player
     */
    public Player getPlayer(Actor actor){
        Player player = null;
        for (int i =0; i<players.size();i++){
            if (players.get(i)==actor){
                player = players.get(i);
            }
        }
        return player;
    }


}
