package game.managers;

import edu.monash.fit2099.engine.items.Item;
import game.items.MagicalItem;

import java.util.ArrayList;

/**
 * <h1>MagicalItemManager</h1>
 * A class that use to manage the magical items.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see MagicalItem
 */
public class MagicalItemManager {
    /**
     * A list of magical item instances (any classes that extends MagicalItem,
     * such as PowerStar implements MagicalItem will be stored in here)
     */
    private ArrayList<MagicalItem> magicalItemList;

    /**
     * A singleton magical item manager instance
     */
    private static MagicalItemManager instance;

    /**
     * Private constructor that initialise a new MagicalItemList as the class attribute
     */
    private MagicalItemManager() {
        magicalItemList = new ArrayList<>();
    }

    /**
     * Get the singleton instance of magical item manager
     * @return MagicalItemManager singleton instance
     */
    public static MagicalItemManager getInstance() {
        if (instance == null) {
            instance = new MagicalItemManager();
        }
        return instance;
    }

    /**
     * Add a magical item to the MagicalItemList
     * @param item a magical item
     */
    public void appendMagicalItem(MagicalItem item) {
        this.magicalItemList.add(item);
    }

    /**
     * Getter for the ArrayList MagicalItemList
     * @return ArrayList MagicalItemList
     */
    public ArrayList<MagicalItem> getMagicalItems() {
        return new ArrayList<MagicalItem>(this.magicalItemList);
    }

    /**
     * Getter for the magical item if the item is a magical item
     *
     * @param item which is the item
     * @return a magical item
     */
    public MagicalItem getMagicalItem(Item item){
        MagicalItem returnItem = null;
        for (int i =0; i<magicalItemList.size();i++){
            if (magicalItemList.get(i)==item){
                returnItem = magicalItemList.get(i);
            }
        }
        return returnItem;
    }

    /**
     * Remove an item in the list if the item is a magical item
     *
     * @param item which is the item
     */
    public void removeMagicalItem(Item item){
        magicalItemList.remove(item);
    }
}
