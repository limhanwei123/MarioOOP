package game.enemies;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.enums.EnemyStatus;
import game.items.Key;

/**
 * <h1>Bowser</h1>
 * A type of enemy boss that stands near Princess Peach to prevent you from going to her
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 22/5/2022
 *  @see Enemy
 */
public class Bowser extends Enemy{

    /**
     * Bowser damage on other actors
     */
    private int damage = 80;

    /**
     * default location of Bowser. Spawns at here when the game is resetted.
     */
    private Location default_location;

    /**
     * Attack action
     */
    private String attack = "smack";

    /**
     * Constructor.
     */
    public Bowser() {
        super("Bowser", 'B', 500);
        this.addCapability(EnemyStatus.FIRE);
    }

    /**
     * Constructor
     *
     * @param location location that is spawned at.
     */
    public Bowser(Location location) {
        super("Bowser", 'B', 500);
        this.default_location = location;
        this.addCapability(EnemyStatus.FIRE);
    }

    /**
     * Overriding hurt function for Bowser to spawn key item.
     *
     * @param points number of hitpoints to deduct.
     */
    @Override
    public void hurt(int points) {
        super.hurt(points);
        if (!this.isConscious()){
            spawnLocation.map().removeActor(this);
            spawnLocation.addItem(new Key());
        }
    }

    /**
     * Override getIntrinsicWeapon() from Actor class.
     *
     * @see Actor#getIntrinsicWeapon()
     * @return a new IntrisicWeapon based on Goomba damage and attack.
     */
    @Override
    protected IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(damage,attack);
    }

    /**
     * To figure out what to do next by calling playturn() in enemy class.
     *
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @see Actor#playTurn(ActionList, Action, GameMap, Display)
     * @return an action for Bowser to perform
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        Action action = super.playTurn(actions, lastAction, map, display);
        return action;
    }

    /**
     * Reset Bowser to its' default location plus healing Bowser
     */
    @Override
    public void resetInstance() {
        if (spawnLocation != null && default_location != null) {
            spawnLocation.map().moveActor(this, default_location);
            this.resetMaxHp(getMaxHp());
            if (this.hasCapability(EnemyStatus.AGGRO)){
                this.removeCapability(EnemyStatus.AGGRO);
            }
        }
    }
}
