package game.enemies;

import edu.monash.fit2099.engine.actions.*;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.behaviours.WanderBehaviour;

/**
 * <h1>List Of Koopas</h1>
 * An abstract class of different type of Koopa in this game
 * It is a tortoise that hits hard and likes to hide in his shell
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 22/5/2022
 *  @see Enemy
 */
public abstract class ListOfKoopas extends Enemy{

    /**
     * Koopas damage on other actors
     */
    private int damage = 30;

    /**
     * Attack action
     */
    private String attack = "punches";

    /**
     * Constructor.
     */
    public ListOfKoopas(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints);
        this.addBehaviour(10, new WanderBehaviour());
    }

    /**
     * Constructor.
     *
     * @param location location of where it is spawned.
     */
    public ListOfKoopas(String name, char displayChar, int hitPoints, Location location) {
        super(name, displayChar, hitPoints, location);
        this.addBehaviour(10, new WanderBehaviour());
    }

    /**
     * Override hurt() from Actor class.
     * Spawns a shell and remove from map when it is not conscious/dead.
     *
     * @see Actor#hurt(int)
     * @param points number of hitpoints to deduct.
     */
    @Override
    public void hurt(int points) {
        super.hurt(points);
        if (!this.isConscious()){
            spawnLocation.map().removeActor(this);
            spawnLocation.addActor(new Shell(spawnLocation));
        }
    }

    /**
     * Override getIntrinsicWeapon() from Actor class.
     *
     * @see Actor#getIntrinsicWeapon()
     * @return a new IntrisicWeapon based on Koopas damage and attack.
     */
    @Override
    protected IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(damage,attack);
    }

    /**
     * To figure out what to do next by calling playturn() in enemy class.
     *
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @see Actor#playTurn(ActionList, Action, GameMap, Display)
     * @return an action for Koopa to perform
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        if(!this.isConscious()){
            return new DoNothingAction();
        }
        Action action = super.playTurn(actions, lastAction, map, display);
        return action;
    }
}
