package game.enemies;

import edu.monash.fit2099.engine.positions.Location;
import game.enums.EnemyStatus;

/**
 * <h1>Flying Koopa</h1>
 * A mutated Koopa that can fly around
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 20/5/2022
 *  @see Enemy
 */
public class FlyingKoopa extends ListOfKoopas {

    /**
     * Constructor with fly capability
     */
    public FlyingKoopa() {
        super("Flying Koopa", 'F', 150);
        this.addCapability(EnemyStatus.FLY);
    }

    /**
     * Constructor with spawn location and fly capability
     *
     * @param location spawn location
     */
    public FlyingKoopa(Location location) {
        super("Flying Koopa", 'F', 150, location);
        this.addCapability(EnemyStatus.FLY);
    }

}
