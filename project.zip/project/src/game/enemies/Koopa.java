package game.enemies;

import edu.monash.fit2099.engine.positions.Location;

/**
 * <h1>Koopa</h1>
 * A normal Koopa that walks on ground
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 20/5/2022
 *  @see Enemy
 */
public class Koopa extends ListOfKoopas {
    /**
     * Constructor
     */
    public Koopa() {
        super("Koopa", 'K', 100);
    }

    /**
     * Constructor with spawn location
     */
    public Koopa(Location location) {
        super("Koopa", 'K', 100, location);
    }
}
