package game.enemies;

import edu.monash.fit2099.engine.positions.Location;
import game.behaviours.WanderBehaviour;
import game.enums.EnemyStatus;
import game.weapons.FireBow;

/**
 * <h1>Bowyer</h1>
 * A type of enemy with a bow that performs range attack
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 22/5/2022
 *  @see Enemy
 */
public class Bowyer extends Enemy {

    /**
     * default location of Bowyer. Spawns at here when the game is resetted.
     */
    private Location default_location;

    /**
     * Constructor.
     */
    public Bowyer() {
        super("Bowyer", 'S', 500);
        addItemToInventory(new FireBow());
        this.addBehaviour(10, new WanderBehaviour());
    }

    /**
     * Constructor.
     * @param location Spawn Location of Bowyer
     */
    public Bowyer(Location location) {
        super("Bowyer", 'S', 500);
        this.default_location = location;
        addItemToInventory(new FireBow());
        this.addBehaviour(10, new WanderBehaviour());
    }

    /**
     * Reset the status of Bowyer and move back to its original location
     */
    @Override
    public void resetInstance() {
        if (spawnLocation != null && default_location != null) {
            spawnLocation.map().moveActor(this, default_location);
            this.resetMaxHp(getMaxHp());
            if (this.hasCapability(EnemyStatus.AGGRO)){
                this.removeCapability(EnemyStatus.AGGRO);
            }
        }
    }
}
