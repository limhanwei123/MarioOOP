package game.enemies;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.AttackAction;
import game.enums.EnemyStatus;
import game.enums.PlayerStatus;
import game.items.SuperMushroom;

/**
 * <h1>Shell</h1>
 * Koopa's hide place
 * A type of enemy
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see ListOfKoopas ,Enemy
 */
public class Shell extends Enemy{
    /**
     * A constructor for Koopa's Shell
     * @param location Location of the Shell
     * @see ListOfKoopas ,Enemy
     */
    public Shell(Location location){
        super("Shell", 'D', 1, location);
        addCapability(EnemyStatus.SHELL);
    }

    /**
     * Select and return an action to perform on the current turn.
     *
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return the Action to be performed
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        return new DoNothingAction();
    }

    /**
     * Do some damage to the current Shell.
     *
     * If the Shell's hitpoints go down to zero, it will be knocked out
     * and a SuperMushroom will drop.
     *
     * @param points number of hitpoints to deduct.
     */
    @Override
    public void hurt(int points){
        super.hurt(points);
        if (!this.isConscious()){
            dropMushroom();
        }
    }

    /**
     * Drop a SuperMushroom on the current Location of Shell
     */
    public void dropMushroom(){
        if (spawnLocation != null){
            spawnLocation.addItem(new SuperMushroom());
            spawnLocation.map().removeActor(this);
        }
    }

    /**
     * Returns a new collection of the Actions that the otherActor can do to the current Actor.
     *
     * @param otherActor the Actor that might be performing attack
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return A collection of Actions.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        // if Player has Wrench, it can break the Shell
        if(otherActor.hasCapability(PlayerStatus.BREAK_SHELL)) {
            actions.add(new AttackAction(this,direction));
        }
        return actions;
    }
}
