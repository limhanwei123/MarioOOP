package game.enemies;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.enums.EnemyStatus;

/**
 * <h1>Piranha Plant</h1>
 * An enemy that spawn on the warp pipe
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 20/5/2022
 *  @see Enemy
 */
public class PiranhaPlant extends Enemy{

    /**
     * PiranhaPlant damage on other actors
     */
    private int damage = 90;

    /**
     * Attack action
     */
    private String attack = "chomps";

    /**
     * Constructor
     *
     * @param location location of piranha spawn
     */
    public PiranhaPlant(Location location) {
        super("Piranha Plant", 'Y', 150, location);
        this.addCapability(EnemyStatus.PIRANHA);
    }

    /**
     * Method to get its own intrinsic weapon
     *
     * @return it's intrinsic weapon
     */
    @Override
    protected IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(damage,attack);
    }

    /**
     * To figure out what to do next by calling playturn() in enemy class.
     *
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @see Actor#playTurn(ActionList, Action, GameMap, Display)
     * @return an action for Koopa to perform
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        if(!this.isConscious()){
            return new DoNothingAction();
        }
        Action action = super.playTurn(actions, lastAction, map, display);
        return action;
    }

    /**
     * Increase the piranha plant by 50 hp when the game is reset
     */
    @Override
    public void resetInstance() {
        this.increaseMaxHp(50);
        this.resetMaxHp(this.getMaxHp());
    }
}
