package game.enemies;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.AttackAction;
import game.behaviours.AttackBehaviour;
import game.enums.*;
import game.interfaces.Behaviour;
import game.interfaces.Resettable;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * <h1>Enemy</h1>
 * Enemy is an abstract class that extends Actor.
 * This class is to handle all the enemies present.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Actor
 *  @see Resettable
 */
public abstract class Enemy extends Actor implements Resettable {

    /**
     * Using hashMap to know the priority of the behaviors and store the behavior
     */
    private final Map<Integer, Behaviour> behaviours = new HashMap<>(); // priority, behaviour

    /**
     * Random number generator
     */
    protected Random random = new Random();

    /**
     * spawn location of the enemy
     */
    protected Location spawnLocation;

    /**
     * Constructor
     *
     * adding HOSTILE_TO_PLAYER capability, adding behavior and register inside reset instance.
     *
     * @param name        the name of the Actor
     * @param displayChar the character that will represent the Actor in the display
     * @param hitPoints   the Actor's starting hit points
     */
    public Enemy(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints);
        this.addCapability(EnemyStatus.HOSTILE_TO_PLAYER);
        this.behaviours.put(8, new AttackBehaviour());
        this.registerInstance();

    }

    /**
     * Constructor
     *
     * adding HOSTILE_TO_PLAYER capability, adding behavior and register inside reset instance.
     *
     * @param name        the name of the Actor
     * @param displayChar the character that will represent the Actor in the display
     * @param hitPoints   the Actor's starting hit points
     * @param spawnLocation the spawn location of the enemy
     */
    public Enemy(String name, char displayChar, int hitPoints, Location spawnLocation) {
        super(name, displayChar, hitPoints);
        this.addCapability(EnemyStatus.HOSTILE_TO_PLAYER);
        this.spawnLocation = spawnLocation;
        this.behaviours.put(8, new AttackBehaviour());
        this.registerInstance();
    }

    /**
     * Player have attack action when it is close to an enemy.
     *
     * @param otherActor the Actor that might perform an action.
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return list of actions
     * @see PlayerStatus#HOSTILE_TO_ENEMY
     */
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        // it can be attacked only by the HOSTILE opponent, and this action will not attack the HOSTILE enemy back.
        if(otherActor.hasCapability(PlayerStatus.HOSTILE_TO_ENEMY)) {
            actions.add(new AttackAction(this,direction));
        }
        return actions;
    }

    /**
     * Method that helps enemy do on each turn from their behaviors.
     *
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @see Action
     * @see Behaviour
     * @return an action that can be performed
     */
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        if(this.isConscious()) {
            Location location = map.locationOf(this);
            this.spawnLocation = map.at(location.x(), location.y());
        }
        if(!this.isConscious()){
            return new DoNothingAction();
        }

        for(Behaviour Behaviour : behaviours.values()) {
            Action action = Behaviour.getAction(this, map);
            if (action != null)
                return action;
        }
        return new DoNothingAction();
    }

    /**
     * helps add more behavior for its child classes
     *
     * @param priority priority of the behaviors
     * @param behaviour behaviors for NPC to have actions.
     */
    public void addBehaviour (Integer priority,Behaviour behaviour){
        this.behaviours.put(priority, behaviour);
    }

    /**
     * Remove actor/enemy if spawn location is not null.
     * Override method from Resettable.
     */
    @Override
    public void resetInstance() {
        if (spawnLocation != null){
            spawnLocation.map().removeActor(this);
        }
    }

}
