package game.enemies;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.behaviours.WanderBehaviour;
import game.interfaces.Resettable;

import java.util.Random;

/**
 * <h1>Goomba</h1>
 * A little fungus guy
 * A type of enemy
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Enemy
 */
public class Goomba extends Enemy {

	/**
	 * Random number generator
	 */
	private Random random = new Random();

	/**
	 * Chance to remove from map
	 */
	private int suicideChance = 10;

	/**
	 * Goomba damage on other actors
	 */
	private int damage = 10;

	/**
	 * Attack action
	 */
	private String attack = "kicks";

	/**
	 * Constructor.
	 */
	public Goomba() {
		super("Goomba", 'g', 20);
		this.addBehaviour(10, new WanderBehaviour());
	}


	/**
	 * Constructor.
	 *
	 * @param location location of where it is spawned.
	 */
	public Goomba(Location location) {super("Goomba", 'g', 20, location);
		this.addBehaviour(10, new WanderBehaviour());}

	/**
	 * Override getIntrinsicWeapon() from Actor class.
	 *
	 * @see Actor#getIntrinsicWeapon()
	 * @return a new IntrisicWeapon based on Goomba damage and attack.
	 */
	@Override
	protected IntrinsicWeapon getIntrinsicWeapon() {
		return new IntrinsicWeapon(damage,attack);
	}

	/**
	 * To figure out what to do next by calling playturn() in enemy class.
	 * Also checking if Goomba suicides.
	 *
	 * @param actions    collection of possible Actions for this Actor
	 * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
	 * @param map        the map containing the Actor
	 * @param display    the I/O object to which messages may be written
	 * @see Actor#playTurn(ActionList, Action, GameMap, Display)
	 * @return an action for Goomba to perform
	 */
	@Override
	public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
		Action action = super.playTurn(actions, lastAction, map, display);
		if(random.nextInt(100) <= suicideChance || !this.isConscious()){
			map.removeActor(this);
			return new DoNothingAction();
		}
		return action;
	}




}
