package game.interfaces;

/**
 * <h1>CoinExchange</h1>
 *
 * This interface allows actor to transfer their coins to and from
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 * @see game.Player
 */
public interface CoinExchange {

    /**
     * Add the value of coins to the instance's wallet
     * @param coins the value of coins to be added
     * @return boolean to indicate if the coins are successfully added.
     */
    default boolean plusCoins(int coins){return false;}

    /**
     * Minus the value of coins from the instance's wallet
     * @param coins the value of coins to be subtracted
     * @return boolean to indicate if the coins are successfully subtracted.
     */
    default boolean minusCoins(int coins){return false;}

    /**
     * Getter to get the number of coins(value) the instance currently have
     * @return integer wallet value
     */
    int getCoins();

}
