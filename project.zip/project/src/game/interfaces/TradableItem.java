package game.interfaces;

/**
 * <h1>TradableItem</h1>
 *
 * This interface allows an item to be tradable (etc buy from toad)
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 */
public interface TradableItem {
    /**
     * Getter to get the price of TradableItem
     * @return integer price of TradableItem
     */
    int getPrice();
}
