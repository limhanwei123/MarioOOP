package game.behaviours;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.AttackAction;
import game.actions.FireAttackAction;
import game.actions.FireBowAction;
import game.enums.EnemyStatus;
import game.enums.PlayerStatus;
import game.enums.WeaponStatus;
import game.interfaces.Behaviour;

/**
 * <h1>AttackBehavior</h1>
 * Special Action for enemies to run a attack behavior.
 * Acts as on AI for actions for NPC(non-playable character).
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Behaviour
 *  @see Action
 *  @see AttackAction
 *  @see FollowBehaviour
 */
public class AttackBehaviour implements Behaviour {

    /**
     * The Actor that is to be followed by another actor.
     */
    private Actor actorToFollow;

    /**
     * Allows actor to attack action each turn by itself without user input actions.
     *
     * @param actor the Actor acting
     * @param map the GameMap containing the Actor
     * @return an Action that actor can perform, or null if actor can't do this.
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {

        // check surroundings for Actors
        for(Exit exit : map.locationOf(actor).getExits()){
            Location destination = exit.getDestination();
            // currently used for enemies.
            // Enemies attack those that have HOSTILE_TO_ENEMY
            if (destination.containsAnActor()){
                Actor target = destination.getActor();
                if (target.hasCapability(PlayerStatus.HOSTILE_TO_ENEMY)){
                    actorToFollow = target;
                    if (!actor.hasCapability(EnemyStatus.PIRANHA))
                        actor.addCapability(EnemyStatus.AGGRO);
                    if (actor.hasCapability(EnemyStatus.FIRE)){
                        return new FireAttackAction(target, exit.getName());
                    }
                    return new AttackAction(target, exit.getName());
                }
            }
        }

        // check if the actor is long range attack or normal melee attack
        if (actor.hasCapability(WeaponStatus.RANGE_ATTACK) && actorToFollow != null && actor.hasCapability(EnemyStatus.AGGRO)){
            Location here = map.locationOf(actor);
            Location there = map.locationOf(actorToFollow);
            // check is there an actor is in the shooting range
            if (there.x() <= here.x() + 3 && there.x() >= here.x() - 3 && there.y() <= here.y() + 3 && there.y() >= here.y() - 3 ){
                return new FireBowAction(actorToFollow, "bow");
            }
        }
        // checks if the actorToFollow is dead and checks if actor (enemy) has AGGRO status.
        if (actorToFollow != null && actor.hasCapability(EnemyStatus.AGGRO)){
            // adds follow behavior to enemy and target player.
            return new FollowBehaviour(actorToFollow).getAction(actor, map);
        }
        return null;

    }
}
