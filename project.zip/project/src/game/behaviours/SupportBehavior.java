package game.behaviours;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.SupportAction;
import game.interfaces.Behaviour;

/**
 * <h1>SupportBehavior</h1>
 * Special Action for enemies to run a support behavior.
 * Acts as on AI for actions for NPC(non-playable character).
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 22/5/2022
 *  @see Behaviour
 *  @see Action
 *  @see SupportAction
 */
public class SupportBehavior implements Behaviour {

    /**
     * The Actor that is to be supported by another actor.
     */
    private final Actor target;

    /**
     * heal amount
     */
    private int heal;

    /**
     * add damage amount
     */
    private int damage;

    /**
     * Constructor
     *
     * @param subject target to support
     * @param heal heal amount
     * @param damage add damage amount
     */
    public SupportBehavior(Actor subject, int heal , int damage) {
        this.target = subject;
        this.heal = heal;
        this.damage = damage;
    }

    /**
     * Allows actor to support action each turn by itself without user input actions.
     *
     * @param actor the Actor acting
     * @param map the GameMap containing the Actor
     * @return an Action that actor can perform, or null if actor can't do this.
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {

        // check is the player still alive
        if(!map.contains(target) || !map.contains(actor))
            return null;

        Location here = map.locationOf(actor);
        Location there = map.locationOf(target);

        // get the surrounding of actor
        for (Exit exit : here.getExits()) {
            Location destination = exit.getDestination();
            // if supporting target is in the surrounding
            if (destination == there){
                return new SupportAction(target, heal, damage);
            }
        }
        return null;
    }

}
