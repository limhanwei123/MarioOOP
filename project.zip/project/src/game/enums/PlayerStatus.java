package game.enums;

/**
 *  <h1>PlayerStatus</h1>
 *
 * Use this enum class to give `buff` or `debuff`.
 * It is also useful to give a `state` to abilities or actions that can be attached-detached.
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 * @see game.Player
 */
public enum PlayerStatus {
    /**
     * use this status to be considered hostile towards enemy (e.g., to be attacked by enemy)
     */
    HOSTILE_TO_ENEMY,
    /**
     * use this status to tell that current instance has "grown".
     */
    TALL,
    /**
     * with consume of power star,can destroy Higher Grounds ,gain Immunity,instantly kill enemies
     */
    POWER,
    /**
     * can trade with toad
     */
    TRADE_WITH_TOAD,
    /**
     * can break shell
     */
    BREAK_SHELL,
    /**
     * can enter floor
     */
    CAN_ENTER_FLOOR,
    /**
     * can enter pipe
     */
    CAN_ENTER_PIPE,
    /**
     * is player can enter some place enemies can't
     */
    PLAYER,

    /**
     * when the player get the key from Bowser
     */
    HAS_KEY,

    /**
     * status for yoshi
     */
    ALLIES,
}
