package game.enums;

/**
 * <h1>GroundStatus</h1>
 *
 * Status of a Ground
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 * @see edu.monash.fit2099.engine.positions.Ground
 */
public enum GroundStatus {
    /**
     * a Fertile Ground
     */
    FERTILE,
}
