package game.enums;

/**
 *  <h1>WeaponStatus</h1>
 *
 *Status of a Weapon
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 22/5/2022
 * @see game.enemies.Bowyer
 */
public enum WeaponStatus {
    /**
     * ability to attack from distance
     */
    RANGE_ATTACK
}
