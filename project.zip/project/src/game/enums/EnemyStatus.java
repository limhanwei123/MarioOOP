package game.enums;

import game.enemies.Enemy;

/**
 * <h1>EnemyStatus</h1>
 *
 * Status of an enemy `buff` or `debuff`
 * It is also useful to give a `state` to abilities or actions that can be attached-detached.
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 * @see Enemy
 */
public enum EnemyStatus {
    /**
     * use this status to be considered hostile towards player (e.g., to be attacked by player)
     */
    HOSTILE_TO_PLAYER,
    /**
     * to indicate that enemy is lured by player
     */
    AGGRO,
    /**
     * dormant state of Koopa
     */
    SHELL,
    /**
     * is piranha plant
     */
    PIRANHA,
    /**
     * ability to fly
     */
    FLY,

    /**
     * status for Bowser to perform fire attack
     */
    FIRE,
}
