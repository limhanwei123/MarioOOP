package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.Player;
import game.managers.PlayerManager;

import java.util.Random;

/**
 * <h1>SupportAction</h1>
 * Special Action for actor to reset.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 22/5/2022
 *  @see Action
 */
public class SupportAction extends Action {

    /**
     * Random number generator
     */
    private Random random = new Random();

    /**
     * chance to heal or add damage
     */
    private int chance = 50;

    /**
     * The Actor that is to be supported
     */
    private Actor target;

    /**
     * heal amount
     */
    private int heal;

    /**
     * add damage amount
     */
    private int damage;

    /**
     * Constructor.
     *
     * @param target the Actor to support
     * @param heal heal amount
     * @param damage add damage amount
     */
    public SupportAction(Actor target, int heal, int damage) {
        this.target = target;
        this.heal = heal;
        this.damage = damage;
    }

    /**
     * Allow the Actor to support targeted actor.
     *
     * Overrides Action.execute()
     *
     * @see Action#execute(Actor, GameMap)
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a description of the Action suitable for the menu
     */
    @Override
    public String execute(Actor actor, GameMap map) {

        String ret = actor + "";

        Player player = PlayerManager.getInstance().getPlayer(target);

        if (random.nextInt(100) <= chance){
            player.heal(heal);
            ret += " healed " + target + " by " + heal + ".";
        }
        else{
            player.addDamage(damage);
            ret += " added damage of " + target + " by " + damage + ".";
        }

        return ret;
    }

    /**
     * Returns a description of the support from actor to target.
     *
     * @param actor The actor performing the action.
     * @return a String, e.g. "Actor can support Player"
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " can support " + target;
    }
}
