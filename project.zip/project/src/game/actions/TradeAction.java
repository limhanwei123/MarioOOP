package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import game.Player;
import game.managers.PlayerManager;

/**
 * <h1>TradeAction</h1>
 * Special Action for actors to trade with toad.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Action
 */
public class TradeAction extends Action {
    /**
     * The item to be traded
     */
    private Item item;

    /**
     * The price of the item
     */
    private int price;

    /**
     * Constructor
     *
     * @param item item to be traded.
     * @param price price of the item.
     */
    public TradeAction(Item item, int price){
        this.item = item;
        this.price = price;
    }

    /**
     * Allow the Player to trade.
     *
     * Overrides Action.execute()
     *
     * @see Action#execute(Actor, GameMap)
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a description of the Action suitable for the menu
     */
    @Override
    public String execute(Actor actor, GameMap map) {

        // helps get instance of player without down casting.
        Player player = PlayerManager.getInstance().getPlayer(actor);

        // check if player is able to afford it.
        if (player.getCoins()-this.price >= 0){
            player.addItemToInventory(this.item);
            player.minusCoins(this.price);
            return "Thank you for purchasing <3";
        }
        else{
            return "You don't have enough coins!";
        }
    }

    /**
     * Returns a description trade action for the player.
     *
     * @param actor The actor performing the action.
     * @return a String, e.g. "Player buys Super Mushroom ($400)"
     */
    @Override
    public String menuDescription(Actor actor) {

        return actor + " buys " + this.item + " ($" + this.price +")";
    }
}
