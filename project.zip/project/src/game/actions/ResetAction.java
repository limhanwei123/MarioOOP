package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.managers.ResetManager;

/**
 * <h1>ResetAction</h1>
 * Special Action for actor to reset.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Action
 */
public class ResetAction extends Action {

    /**
     * Allow the Actor to reset.
     *
     * Overrides Action.execute()
     *
     * @see Action#execute(Actor, GameMap)
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a description of the Action suitable for the menu
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        // calls run() function on ResetManager.
        ResetManager.getInstance().run();
        return "The Game has been reset";
    }

    /**
     * Returns a description of game reset.
     *
     * @param actor The actor performing the action.
     * @return a String, e.g. "Reset the game."
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Reset the game.";
    }

    /**
     * Returns this Action's hotkey.
     *
     * @return the hotkey
     */
    @Override
    public String hotkey(){
        return "r";
    }
}
