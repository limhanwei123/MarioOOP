package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.PickUpItemAction;
import edu.monash.fit2099.engine.positions.GameMap;
import game.Player;
import game.managers.PlayerManager;
import game.items.Coins;

/**
 * <h1>PickUpCoinAction</h1>
 * Special Action to allow coins to be picked up.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Action
 *  @see PickUpItemAction
 */
public class PickUpCoinAction extends PickUpItemAction {

    /**
     * The item that inherits from Coins
     */
    private Coins coin;

    /**
     * Constructor.
     *
     * @param coin the coin to pick up.
     */
    public PickUpCoinAction(Coins coin) {
        super(coin);
        this.coin = coin;
    }

    /**
     * Allow the Actor to pick up coins.
     *
     * Overrides Action.execute()
     *
     * @see Action#execute(Actor, GameMap)
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a description of the Action suitable for the menu
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        String ret = "";
        if (PlayerManager.getInstance().getPlayers().contains(actor)) {
            Player player = PlayerManager.getInstance().getPlayer(actor);
            map.locationOf(player).removeItem(coin);
            player.plusCoins(coin.getCoins());
            ret += actor + " picked up $" + coin.getCoins() + " coins";
        }
        else{
            throw new IllegalStateException("The actor could not perform PickUpCoinAction");
        }
        return ret;
    }

    /**
     * Returns a description of actor picking up the coin.
     *
     * @param actor The actor performing the action.
     * @return a String, e.g. "Player can pick up $20 coins."
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " can pick up $" + coin.getCoins() + " coins";
    }
}
