package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.Player;
import game.managers.PlayerManager;
import game.managers.WarpPipeManager;
import game.terrains.WarpPipe;

import java.util.ArrayList;
import java.util.Random;

/**
 * <h1>TeleportAction</h1>
 * An action to teleport the player to a different map
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 22/5/2022
 *  @see Action
 */
public class TeleportAction extends Action {

    /**
     * Random number generator
     */
    private Random random = new Random();

    /**
     * Current WarpPipe that teleports the player
     */
    private WarpPipe warpPipe;

    /**
     * Hotkey used in menu
     */
    private String hotkey;

    /**
     * Constructor
     * @param warpPipe WarpPipe that teleports the player
     */
    public TeleportAction(WarpPipe warpPipe) {
        this.warpPipe = warpPipe;
        this.hotkey ="t";
    }

    /**
     * Getter for hotkey
     * @return a String of the hotkey
     */
    @Override
    public String hotkey() {
        return this.hotkey;
    }

    /**
     * Teleports the player from one WarpPipe (from a map ) to another WarpPipe (to another map).
     * This applies for player's ally Yoshi as well
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a String stating the direction the actor teleports to
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        Location previousLocation = warpPipe.getPreviousLocation();
        Location moveToLocation = warpPipe.getMoveToLocation();
        Location currentLocation = map.locationOf(actor);
        Player player = PlayerManager.getInstance().getPlayer(actor);

        if (previousLocation == null) {
            if (moveToLocation.containsAnActor()) {
                map.removeActor(moveToLocation.getActor());
            }
            map.moveActor(player, moveToLocation);
            Location randomDestination = getYoshiTeleportLocation(map, moveToLocation);
            map.moveActor(player.getYoshi(), randomDestination);
        }
        else{
            if (previousLocation.containsAnActor()) {
                map.removeActor(previousLocation.getActor());
            }
            map.moveActor(actor,previousLocation);


            Location randomDestination = getYoshiTeleportLocation(map, previousLocation);
            map.moveActor(player.getYoshi(), randomDestination);
        }
        WarpPipe moveToWarpPipe = WarpPipeManager.getInstance().getWarpPipe(moveToLocation);
        moveToWarpPipe.setPreviousLocation(currentLocation);
        return actor + " teleports " + warpPipe.getDirection();

    }

    private Location getYoshiTeleportLocation(GameMap map, Location moveToLocation) {
        ArrayList<Location> yoshiLocation = new ArrayList<>();
        for (Exit destination : moveToLocation.getExits()){
            yoshiLocation.add(destination.getDestination());
        }
        int randomIndex = random.nextInt(yoshiLocation.size());
        Location randomDestination = yoshiLocation.get(randomIndex);

        if (randomDestination.containsAnActor()){
            map.removeActor(randomDestination.getActor());
        }
        return randomDestination;
    }

    /**
     * Returns a description of the actor to teleport
     * @param actor The actor performing the action.
     * @return a String indicating that player is capable of teleporting to another map
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " can teleport " + warpPipe.getDirection();
    }


}
