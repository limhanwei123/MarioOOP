package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.managers.MagicalItemManager;
import game.items.MagicalItem;


/**
 * <h1>ConsumeItemAction</h1>
 * Special Action for Actors to consume items.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Action
 */
public class ConsumeItemAction extends Action {

    /**
     * An item that inherits MagicalItem
     */
    private MagicalItem item;

    /**
     * Constructor.
     *
     * @param item the item that is to be consumed.
     */
    public ConsumeItemAction(MagicalItem item) {
        this.item = item;
    }

    /**
     * Allow the Actor to consume items.
     *
     * Overrides Action.execute()
     *
     * @see Action#execute(Actor, GameMap)
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a description of the Action suitable for the menu
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        actor.removeItemFromInventory(item);
        item.grantSuperPower(actor);
        MagicalItemManager.getInstance().removeMagicalItem(item);
        return actor + " has consumed "+ item;
    }

    /**
     * Returns a description of the actor to consume the item.
     *
     * @param actor The actor performing the action.
     * @return a String, e.g. "Player can consume Power Star"
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " can consume " + item;
    }
}
