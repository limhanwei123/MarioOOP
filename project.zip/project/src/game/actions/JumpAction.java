package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.terrains.TallTerrain;

import java.util.Random;

/**
 * <h1>JumpAction</h1>
 * Special Action for attacking other Actors.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Action
 */
public class JumpAction extends Action {

    /**
     * The ground that inherits from TallTerrain
     */
    private TallTerrain tallTerrain;

    /**
     * The location that is jumpable.
     */
    private Location jumpableLocation;

    /**
     * The direction to jump
     */
    protected String direction;

    /**
     * Random number generator
     */
    protected Random random = new Random();

    /**
     * Constructor
     *
     * @param tallTerrain ground that can be jumped onto.
     * @param jumpableLocation the location of the ground that can be jumped onto.
     * @param direction the direction of the location of the tallTerrain,
     */
    public JumpAction(TallTerrain tallTerrain, Location jumpableLocation, String direction) {
        this.tallTerrain = tallTerrain;
        this.jumpableLocation = jumpableLocation;
        this.direction = direction;
    }

    /**
     * Allow the actor to jump onto tall terrains.
     *
     * Overrides Action.execute()
     *
     * @see Action#execute(Actor, GameMap)
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a description of the Action suitable for the menu
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        return tallTerrain.jump(actor, jumpableLocation, map);
    }

    /**
     * Returns a description of the actor to jump to the tall terrain.
     *
     * @param actor The actor performing the action.
     * @return a String, e.g. "Player can jump to North, Wall(54,10)"
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " can jump to " + direction + ", " + tallTerrain +"(" +
                jumpableLocation.x() + "," + jumpableLocation.y()+")";
    }

}
