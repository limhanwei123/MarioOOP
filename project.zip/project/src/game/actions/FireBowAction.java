package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.positions.NumberRange;
import edu.monash.fit2099.engine.weapons.Weapon;
import game.items.Fire;

import java.util.Random;

/**
 * <h1>FireBowAction</h1>
 * Special Action for attacking other Actors with when the attacker is equipped
 * with FireBow
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 * @since 22/5/2022
 *  @see Action
 * @see game.weapons.FireBow
 */
public class FireBowAction extends Action {

    /**
     * The Actor that is to be attacked
     */
    protected Actor target;

    /**
     * The direction of incoming attack.
     */
    protected String direction;

    /**
     * Random number generator
     */
    protected Random rand = new Random();

    /**
     * Constructor
     *
     * @param target target the Actor to attack.
     * @param direction direction the direction to attack at.
     */
    public FireBowAction(Actor target, String direction) {
        this.target = target;
        this.direction = direction;
    }

    /**
     * Allows the actor to perform a range attack with fire.
     * Spawns fire on the location of impact.
     * Attack can be blocked by Wall
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a description of the Action suitable for the menu
     * @see game.terrains.Wall
     * @see Fire
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        String result;

        Weapon weapon = actor.getWeapon();

        // random the hit chance based on the weapon used by actor.
        if (!(rand.nextInt(100) <= weapon.chanceToHit())) {
            return actor + " misses " + target + ".";
        }

        int damage = weapon.damage();

        result = actor + " " + weapon.verb() + " " + target + " for " + damage + " damage with fire.";

        Location here = map.locationOf(actor);
        Location there = map.locationOf(target);
        NumberRange xs, ys;
        // Check if Attack blocked
        if (there.x() <= here.x() + 3 && there.x() >= here.x() - 3 && there.y() <= here.y() + 3 && there.y() >= here.y() - 3 ) {
            xs = new NumberRange(Math.min(here.x(), there.x()), Math.abs(here.x() - there.x()) + 1);
            ys = new NumberRange(Math.min(here.y(), there.y()), Math.abs(here.y() - there.y()) + 1);
            for (int x : xs) {
                for (int y : ys) {
                    if (map.at(x, y).getGround().blocksThrownObjects()) {

                        return actor + " fires an arrow at " + target + "... but the arrow was blocked by terrain";
                    }
                }
            }
        }

        target.hurt(damage);
        //add fire to the location of impact
        map.locationOf(target).addItem(new Fire());

        if (!target.isConscious()) {
            ActionList dropActions = new ActionList();
            // drop all items
            for (Item item : target.getInventory())
                dropActions.add(item.getDropAction(actor));
            for (Action drop : dropActions)
                drop.execute(target, map);
            // remove actor
            map.removeActor(target);
            result += System.lineSeparator() + target + " is killed.";
        }

        return result;
    }

    /**
     * Returns a description of the attack from actor to target.
     *
     * @param actor The actor performing the action.
     * @return a String of the menu description
     */
    @Override
    public String menuDescription(Actor actor) {
        return null;
    }
}
