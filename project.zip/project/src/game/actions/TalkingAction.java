package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.enums.PlayerStatus;

import java.util.ArrayList;
import java.util.Random;

/**
 * <h1>TalkingAction</h1>
 * Special Action for actors to talk to toad.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Action
 */
public class TalkingAction extends Action {

    /**
     * Random number generator
     */
    private Random random = new Random();

    /**
     * Constructor
     */
    public TalkingAction(){}
    /**
     * Allow the Actor to talk to toad.
     *
     * Overrides Action.execute()
     *
     * @see Action#execute(Actor, GameMap)
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a description of the Action suitable for the menu
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        int choice;
        boolean flag = false;
        String quotes = "";

    //  loops until random can provide a valid quote based on actor.
        while (!flag) {
            // random choice from the toad.
            choice = random.nextInt(4);

            if (choice == 0) {
                // Gives this quote from toad when player don't have a wrench.
                if(!actor.hasCapability(PlayerStatus.BREAK_SHELL)) {
                    quotes += "You might need a wrench to smash Koopa's hard shells.";
                    flag = true;
                }
            } else if (choice == 1) {
                // Gives this quote from toad when player didn't consume a power star.
                if(!actor.hasCapability(PlayerStatus.POWER)) {
                    quotes += "You better get back to finding the Power Stars.";
                    flag = true;
                }
            } else if (choice == 2) {
                quotes += "The Princess is depending on you! You are our only hope.";
                flag = true;
            } else if (choice == 3) {
                quotes += "Being imprisoned in these walls can drive a fungus crazy :(";
                flag = true;
            }
        }
        return quotes;

    }

    /**
     * Returns a description actor to talk to toad.
     *
     * @param actor The actor performing the action.
     * @return a String, e.g. "Player talks with Toad"
     */
    @Override
    public String menuDescription(Actor actor) {
            return actor + " talks with Toad";
    }
}
