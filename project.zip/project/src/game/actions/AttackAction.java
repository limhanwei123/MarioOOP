package game.actions;

import java.util.Random;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.weapons.Weapon;
import game.enums.EnemyStatus;
import game.enums.PlayerStatus;

/**
 * <h1>AttackAction</h1>
 * Special Action for attacking other Actors.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Action
 */
public class AttackAction extends Action {

	/**
	 * The Actor that is to be attacked
	 */
	protected Actor target;

	/**
	 * The direction of incoming attack.
	 */
	protected String direction;

	/**
	 * Random number generator
	 */
	protected Random rand = new Random();

	/**
	 * Constructor.
	 * 
	 * @param target the Actor to attack.
	 * @param direction the direction to attack at.
	 */
	public AttackAction(Actor target, String direction) {
		this.target = target;
		this.direction = direction;
	}

	/**
	 * Allow the Actor to attack.
	 *
	 * Overrides Action.execute()
	 *
	 * @see Action#execute(Actor, GameMap)
	 * @param actor The actor performing the action.
	 * @param map The map the actor is on.
	 * @return a description of the Action suitable for the menu
	 */
	@Override
	public String execute(Actor actor , GameMap map) {

		String result = null;

		Weapon weapon = actor.getWeapon();

		// random the hit chance based on the weapon used by actor.
		if (!(rand.nextInt(100) <= weapon.chanceToHit())) {
			return actor + " misses " + target + ".";
		}

		int damage = weapon.damage();

		// checks if actor has POWER capability once it consumed Power Star.
		if (actor.hasCapability(PlayerStatus.POWER)) {
			// checks if the target has SHELL capability, checks for Koopa that is in a dormant state.
			if (target.hasCapability(EnemyStatus.SHELL)) {
				// checks if the actor has item WRENCH in inventory
				if (actor.hasCapability(PlayerStatus.BREAK_SHELL)) {
					result = actor + " DESTROYED " + target + " with a wrench.";
					// guarantees to break the shell hp to destory it.
					target.hurt(Integer.MAX_VALUE);
				}
			}
			// if target isn't Koopa in dormant state, instantly killed the target
			else {
				result = actor + " Insta-Killed " + target ;
				target.hurt(Integer.MAX_VALUE);
			}
		}

		// does the same but with actor not having POWER capability.
		else{
			// checks if the target has SHELL capability, checks for Koopa that is in a dormant state.
			if (target.hasCapability(EnemyStatus.SHELL)){
				// checks if the actor has item WRENCH in inventory
				if (actor.hasCapability(PlayerStatus.BREAK_SHELL)){
					result = actor + " DESTROYED " + target + " with a wrench.";
					target.hurt(damage);
				}
			}
			// if target isn't Koopa in dormant state, does normal attack actions on target.
			else {
				// if player which is target has Power Star consumed then it won't take damage.
				if (target.hasCapability(PlayerStatus.POWER)){
					result = actor + " " + weapon.verb() + " can't damage " + target;
				}
				// normal attack actions on target.
				else {
					result = actor + " " + weapon.verb() + " " + target + " for " + damage + " damage.";
					target.hurt(damage);
				}
			}
		}

		if (!target.isConscious()) {
			ActionList dropActions = new ActionList();
			// drop all items
			for (Item item : target.getInventory())
				dropActions.add(item.getDropAction(actor));
			for (Action drop : dropActions)
				drop.execute(target, map);
			// remove actor
			map.removeActor(target);
			result += System.lineSeparator() + target + " is killed.";
		}

		return result;
	}

	/**
	 * Returns a description of the attack from actor to target, and it's direction where the target is at.
	 *
	 * @param actor The actor performing the action.
	 * @return a String, e.g. "Goomba attacks Player at North"
	 */
	@Override
	public String menuDescription(Actor actor) {
		return actor + " attacks " + target + " at " + direction;
	}
}
