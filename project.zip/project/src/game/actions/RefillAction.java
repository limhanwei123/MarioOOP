package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.Player;
import game.items.Water;
import game.managers.PlayerManager;

/**
 * <h1>RefillAction</h1>
 * Special Action for actor to refill water.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 2.0
 *  @since 21/5/2022
 *  @see Action
 */
public class RefillAction extends Action {

    /**
     * Type of water
     */
    private Water water;

    /**
     * Constructor
     *
     * @param water Type of water
     */
    public RefillAction(Water water) {
        this.water = water;
    }

    /**
     * Allow the Actor to refill its bottle.
     *
     * Overrides Action.execute()
     *
     * @see Action#execute(Actor, GameMap)
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a description of the Action suitable for the menu
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        String ret = "";

        // checks if actor is a player
        if (PlayerManager.getInstance().getPlayers().contains(actor)) {
            // gets player object
            Player player = PlayerManager.getInstance().getPlayer(actor);
            // adds water into the stack
            player.addWater(water);
            ret += player + " refilled " + water + " from " + map.locationOf(actor).getGround() + ".";
        }

        return ret;
    }

    /**
     * Returns a description of refilling bottle with water.
     *
     * @param actor The actor performing the action.
     * @return a String, e.g. "Player can refill bottle with Power Water."
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " can refill bottle with " + water;
    }
}
