package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.Weapon;
import game.items.Fire;

import java.util.Random;

/**
 * <h1>FireAttackAction</h1>
 * Special Action for attacking other Actors with Fire.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 22/5/2022
 *  @see Action
 */
public class FireAttackAction extends Action {

    /**
     * The Actor that is to be attacked
     */
    protected Actor target;

    /**
     * The direction of incoming attack.
     */
    protected String direction;

    /**
     * Random number generator
     */
    protected Random rand = new Random();

    /**
     * Constructor.
     *
     * @param target the Actor to attack.
     * @param direction the direction to attack at.
     */
    public FireAttackAction(Actor target, String direction) {
        this.target = target;
        this.direction = direction;
    }

    /**
     * Allow the Actor to attack with fire . Spawns fire on the location of impact
     *
     * Overrides Action.execute()
     *
     * @see Action#execute(Actor, GameMap)
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a description of the Action suitable for the menu
     * @see Fire
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        String result ;

        Weapon weapon = actor.getWeapon();

        // random the hit chance based on the weapon used by actor.
        if (!(rand.nextInt(100) <= weapon.chanceToHit())) {
            return actor + " misses " + target + ".";
        }

        int damage = weapon.damage();

        result = actor + " " + weapon.verb() + " " + target + " for " + damage + " damage with fire.";
        target.hurt(damage);
        //add fire to the location of impact
        map.locationOf(target).addItem(new Fire());

        if (!target.isConscious()) {
            ActionList dropActions = new ActionList();
            // drop all items
            for (Item item : target.getInventory())
                dropActions.add(item.getDropAction(actor));
            for (Action drop : dropActions)
                drop.execute(target, map);
            // remove actor
            map.removeActor(target);
            result += System.lineSeparator() + target + " is killed.";
        }

        return result;
    }

    /**
     * Returns a description of the attack from actor to target.
     *
     * @param actor The actor performing the action.
     * @return a String of the menu description
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " attacks " + target+" with fire";
    }
}
