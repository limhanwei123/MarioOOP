package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;

/**
 * <h1>RescueAction</h1>
 * Special Action for actor to rescue Princess Peach and win the game.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 2.0
 *  @since 22/5/2022
 *  @see Action
 */
public class RescueAction extends Action {

    /**
     * Allow the Actor to rescue Princess Peach.
     *
     * Overrides Action.execute()
     *
     * @see Action#execute(Actor, GameMap)
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a description of the Action suitable for the menu
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        map.removeActor(actor);
        return "You Win";
    }

    /**
     * Returns a description ti rescue Princess Peach.
     *
     * @param actor The actor performing the action.
     * @return a String, e.g. "Player want to rescue the princess with the key?"
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " want to rescue the princess with the key?";
    }

}
