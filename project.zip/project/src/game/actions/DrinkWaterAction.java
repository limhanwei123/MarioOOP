package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.items.Bottle;

/**
 * <h1>DrinkWaterAction</h1>
 * Special Action for drinking water from the bottle.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 2.0
 *  @since 21/5/2022
 *  @see Action
 */
public class DrinkWaterAction extends Action {

    /**
     * Bottle that stores water
     */
    private Bottle bottle;

    /**
     * Action's hotkey.
     */
    private String hotkey;

    /**
     * Constructor
     *
     * @param bottle The bottle that helps stores water
     */
    public DrinkWaterAction(Bottle bottle){
        this.bottle = bottle;
        this.hotkey = "a";
    }


    /**
     * Allow the Actor to drink.
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a description of the Action suitable for the menu
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if (!bottle.isEmpty()){
            return bottle.getWater().grandAbilities();
        }
        else{
            return "Bottle is empty.";
        }
    }

    /**
     * Returns a description of water in the bottle that player is consuming.
     *
     * @param actor The actor performing the action.
     * @return a String, e.g. "Player consumes Bottle[Power Water]"
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " consumes " + bottle;
    }

    /**
     * Returns this Action's hotkey.
     *
     * @return the hotkey
     */
    @Override
    public String hotkey() {
        return this.hotkey;
    }
}
