package game.items;


import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.PickUpCoinAction;
import game.interfaces.Resettable;


/**
 * <h1>Coins</h1>
 *
 * The currency of the game
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 */
public class Coins extends Item implements Resettable {
    /**
     * value of a coin
     */
    private int value;
    /**
     * location of the coin
     */
    private Location location;

    /**
     * Constructor for Coins class
     * @param value the value of this Coin
     * @param location location of the coin
     * @see Resettable
     */
    public Coins(int value, Location location) {
        super("Coins",'$', false);
        this.value = value;
        this.location = location;
        addAction(new PickUpCoinAction(this));
        this.registerInstance();

    }

    /**
     * Getter to get the value of coin
     * @return integer value of coin
     */
    public int getCoins() {
        return value;
    }

    /**
     * Reset the current game by removing coins
     */
    @Override
    public void resetInstance() {
        location.removeItem(this);
    }
}
