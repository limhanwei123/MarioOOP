package game.items;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Location;

/**
 * <h1>Fire</h1>
 * A class that representing the fire that will be throw out when Bowser attack.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 20/5/2022
 *  @see Item
 */
public class Fire extends Item {
    /**
     * The turn of the fire is available on ground
     */
    private int turn;

    /***
     * Constructor.
     */
    public Fire() {
        super( "Fire",'v',false);
        this.turn = 3;
    }

    /**
     * A method to deduct any actor hp by 20 if the actor stand on it in every turn and after 3 turn it will remove
     *
     * @param currentLocation The location of the ground on which we lie.
     */
    @Override
    public void tick(Location currentLocation){
        Actor actor = currentLocation.getActor();
        Display display = new Display();
        turn -= 1;
        if (turn < 0){
            currentLocation.removeItem(this);
        }
        else {
            if (currentLocation.containsAnActor()) {
                actor.hurt(20);
                display.println(this + " damages " + actor + " by 20hp. ");
            }
        }
    }

    /**
     * ToString method
     *
     * @return Fire
     */
    @Override
    public String toString() {
        return "Fire";
    }
}
