package game.items;

import game.Player;

/**
 * <h1>Healing Water</h1>
 * A type of water that can increase damage of player.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 20/5/2022
 *  @see Water
 */
public class PowerWater extends Water{

    /**
     * The player in this game
     */
    private Player player;

    /***
     * Constructor.
     */
    public PowerWater(Player player){
        this.player = player;
    }

    /**
     * Method to increase player's damage after drinking this water
     *
     * @return String in console
     */
    @Override
    public String grandAbilities() {
        player.addDamage(15);
        return player + " damage increased by 15.";
    }

    /**
     * ToString method
     *
     * @return Power Water
     */
    public String toString(){
        return "Power Water";
    }

}
