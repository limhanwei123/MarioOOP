package game.items;

import edu.monash.fit2099.engine.actors.Actor;
import game.enums.PlayerStatus;
import game.interfaces.TradableItem;

/**
 * <h1>SuperMushroom</h1>
 *
 * A type of MagicalItem  that grants the actor the power of
 * jumping freely with a 100% success rate
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 * @see MagicalItem,TradableItem
 */
public class SuperMushroom extends MagicalItem implements TradableItem{
    /**
     * Price of Super Mushroom
     */
    private int price;
    /***
     * Constructor.
     * @see MagicalItem,TradableItem
     */
    public SuperMushroom() {
        super("SuperMushroom",'^', true);
        this.addToMagicalItemManager();
        this.price = 400;
    }

    /**
     * A method to grant super powers(ex:increase max hp, jump over high grounds with 100% success rate)
     * to an actor after consuming the SuperMushroom
     * @param actor
     * @see PlayerStatus -->TALL
     */
    @Override
    public void grantSuperPower(Actor actor) {
        actor.increaseMaxHp(50);
        actor.addCapability(PlayerStatus.TALL);

    }

    /**
     * Return string name of SuperMushroom
     * @return string name of SuperMushroom
     */
    @Override
    public String toString(){
        return "Super Mushroom";
    }

    /**
     * Getter to get the price of SuperMushroom
     * @return integer price of SuperMushroom
     */
    @Override
    public int getPrice() {
        return this.price;
    }
}
