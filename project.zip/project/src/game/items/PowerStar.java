package game.items;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Location;
import game.Player;
import game.enums.PlayerStatus;
import game.interfaces.TradableItem;
import game.managers.PlayerManager;

/**
 * <h1>PowerStar</h1>
 *
 * A type of MagicalItem  that grants the actor the power of
 * destroying Higher Grounds,Immunity towards enemy attack, and
 * instantly kill enemies
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 * @see MagicalItem,TradableItem
 */
public class PowerStar extends MagicalItem implements TradableItem {
    /**
     * Count of the power star fading time
     */
    private int turn = 10;
    /**
     * Price of power star
     */
    private int price;
    /***
     * Constructor.
     * @see MagicalItem,TradableItem
     */
    public PowerStar() {
        super("Power Star", '*', true);
        this.addToMagicalItemManager();
        this.price = 600;
    }

    /**
     * A method to grant super powers(ex:heal,destroy high grounds)
     * to an actor after consuming the PowerStar
     * Reset the turn if the player consume again a new PowerStar
     *
     * @param actor
     * @see PlayerStatus -->POWER
     */
    @Override
    public void grantSuperPower(Actor actor) {
        if (actor.hasCapability(PlayerStatus.POWER)){
            Player player = PlayerManager.getInstance().getPlayer(actor);
            player.resetTurn();
        }
        else {
            actor.addCapability(PlayerStatus.POWER);
        }
        actor.heal(200);
    }

    /**
     * Return string name of power star
     * @return string name of power star
     */
    @Override
    public String toString(){
        return "Power Star";
    }

    /**
     * Inform a carried Item of the passage of time.
     *
     * This method is called once per turn, if the Item is being carried.
     * @param currentLocation The location of the actor carrying this Item.
     * @param actor The actor carrying this Item.
     */
    @Override
    public void tick(Location currentLocation, Actor actor){
        turn -= 1;
        if (turn < 1){
            actor.removeItemFromInventory(this);
        }
    }

    /**
     * Inform an Item on the ground of the passage of time.
     * This method is called once per turn, if the item rests upon the ground.
     * @param currentLocation The location of the ground on which we lie.
     */
    @Override
    public void tick(Location currentLocation){
        turn -= 1;
        if (turn < 1){
            currentLocation.removeItem(this);
        }
    }

    /**
     * Getter to get the price of PowerStar
     * @return integer price of PowerStar
     */
    @Override
    public int getPrice() {
        return this.price;
    }
}
