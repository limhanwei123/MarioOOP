package game.items;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import game.managers.MagicalItemManager;

/**
 * <h1>MagicalItem</h1>
 *
 * An abstract class to group Item with magical powers
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 * @see Item
 */
public abstract class MagicalItem extends Item {


    /***
     * Constructor.
     *  @param name the name of this Item
     * @param displayChar the character to use to represent this item if it is on the ground
     * @param portable true if and only if the Item can be picked up
     * @see Item
     */
    public MagicalItem(String name, char displayChar, boolean portable) {
        super(name, displayChar, portable);

    }

    /**
     * An abstract method to grant super powers to an actor after consuming the MagicalItem
     * @param actor
     */
    public abstract void grantSuperPower(Actor actor);

    /**
     * a method that register current instance to the MagicalItemManager.
     * It allows to downcast an Item to a MagicalItem and also quick access to all
     * MagicalItem
     *
     */
    protected void addToMagicalItemManager(){
        MagicalItemManager.getInstance().appendMagicalItem(this);
    }
}
