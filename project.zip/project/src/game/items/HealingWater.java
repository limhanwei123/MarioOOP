package game.items;

import game.Player;

/**
 * <h1>Healing Water</h1>
 * A type of water that can heal the player.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 20/5/2022
 *  @see Water
 */
public class HealingWater extends Water{

    /**
     * The player in this game
     */
    private Player player;

    /***
     * Constructor.
     */
    public HealingWater(Player player) {
        this.player = player;
    }

    /**
     * Method to increase player's damage after drinking this water
     *
     * @return String in console
     */
    @Override
    public String grandAbilities() {
        player.heal(50);
        return player + " healed by 50.";
    }

    /**
     * ToString method
     *
     * @return Healing Water
     */
    public String toString(){
        return "Healing Water";
    }


}
