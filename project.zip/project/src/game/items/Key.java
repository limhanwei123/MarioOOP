package game.items;

import edu.monash.fit2099.engine.items.Item;
import game.enums.PlayerStatus;

/**
 * <h1>Key</h1>
 * An Key item to rescue Princess.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 20/5/2022
 *  @see Item
 */
public class Key extends Item {
    /***
     * Constructor and add capability of having key for player
     */
    public Key(){
        super("Key", 'k', true);
        this.addCapability(PlayerStatus.HAS_KEY);
    }
}
