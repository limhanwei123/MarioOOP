package game.items;


/**
 * <h1>Water</h1>
 * A abstract class of water.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 20/5/2022
 */
public abstract class Water{

    /***
     * Constructor.
     */
    public Water() {}

    /**
     * Abstract method to get power from the type of water
     */
    public abstract String grandAbilities();

    /**
     * Abstract ToString method
     */
    public abstract String toString();

}
