package game.items;

import edu.monash.fit2099.engine.items.Item;

import java.util.Stack;

/**
 * <h1>Bottle</h1>
 * An bottle item which player have to store water from fountain and drink it.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 20/5/2022
 *  @see Item
 */
public class Bottle extends Item {

    /**
     * Stack to store different water in different fountain
     */
    private Stack<Water> waters;

    /***
     * Constructor.
     */
    public Bottle() {
        super("Bottle", 'b', false);
        this.waters = new Stack<Water>();
    }

    /**
     * Method to get the last water in the bottle
     *
     * @return the last water
     */
    public Water getWater(){
        return waters.pop();
    }

    /**
     * Check whether the bottle is empty or not
     *
     * @return true or false
     */
    public boolean isEmpty(){
        return waters.isEmpty();
    }

    /**
     * Method to get all the water in the bottle
     *
     * @return the whole bottle in stack
     */
    public Stack<Water> getWaters() {
        return waters;
    }

    /**
     * ToString method for console with a fixed format
     *
     * @return Bottle with drinkable water
     */
    public String toString(){
        int p = 0;
        int len = waters.size();

        String res = "Bottle[";

        for (Water i : waters) {
            res += i;
            if (p < len-1){res += ", ";}
            p ++;
        }
        res += "]";
        return res;
    }

}
