package game;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.displays.Menu;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.actions.ConsumeItemAction;
import game.actions.DrinkWaterAction;
import game.actions.ResetAction;
import game.enums.PlayerStatus;
import game.interfaces.CoinExchange;
import game.interfaces.Resettable;
import game.items.Bottle;
import game.items.MagicalItem;
import game.items.Water;
import game.managers.MagicalItemManager;
import game.managers.PlayerManager;

/**
 * <h1>Player</h1>
 * A class that represents the player.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Actor
 */
public class Player extends Actor implements CoinExchange, Resettable {

	/**
	 * The menu in console
	 */
	private final Menu menu = new Menu();

	/**
	 * A wallet to store balance during the game
	 */
	private int wallet;

	/**
	 * turn that use to count the effect of power star for every consume
	 */
	private int turn = 10;

	/**
	 *  to let the player know the game resetted
	 */
	private boolean resetted = false;

	/**
	 *  player intrinsic damage
	 */
	private int damage = 5;

	/**
	 * player attack verb
	 */
	private String attack = "punches";

	/**
	 *  player bottle to drink different water
	 */
	private Bottle bottle;

	/**
	 *  player's pet yoshi
	 */
	private Yoshi yoshi = null;

	/**
	 * Constructor.
	 * add capability to player (HOSTILE_TO_ENEMY, TRADE_WITH_TOAD and CAN_ENTER_FLOOR) and wallet
	 * also added into player manager so that it is manageable and also reset manager (registerInstance)
	 *
	 * @param name        Name to call the player in the UI
	 * @param displayChar Character to represent the player in the UI
	 * @param hitPoints   Player's starting number of hitpoints
	 */
	public Player(String name, char displayChar, int hitPoints) {
		super(name, displayChar, hitPoints);
		this.addCapability(PlayerStatus.HOSTILE_TO_ENEMY);
		this.addCapability(PlayerStatus.TRADE_WITH_TOAD);
		this.addCapability(PlayerStatus.CAN_ENTER_FLOOR);
		this.addCapability(PlayerStatus.PLAYER);
		this.wallet = 1288;
		this.addToPlayerManager();
		this.registerInstance();
		this.bottle = new Bottle();
		this.addItemToInventory(bottle);
	}

	/**
	 * Method to find out what action can be done on that turn depends on whom he met on that turn
	 *
	 * @param actions    collection of possible Actions for this Actor
	 * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
	 * @param map        the map containing the Actor
	 * @param display    the I/O object to which messages may be written
	 * @return all the action menu description that can be done by the player
	 */
	@Override
	public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {

		//check if the last action is reset or not, if yes, turn the boolean to true since it only can be reset once
		if (lastAction.hotkey() == "r" && lastAction != null){
			resetted = true;
		}

		//if the game is not been reset, the player can perform reset action
		if (!resetted) {
			actions.add(new ResetAction());
		}

		//if the player have power star effect, the console will show it that he is invincible and how many turn left for the effect
		if (hasCapability(PlayerStatus.POWER)){
			display.println("Mario is INVINCIBLE!");
			display.println("Mario consumes Power Star - " + turn + " turns remaining");

			turn -= 1;
		}

		//if 10 turn is finish, remove the power star effect
		if (turn < 1){
			removeCapability(PlayerStatus.POWER);
			this.resetTurn();
		}

		//print the hp and wallet balance
		display.println(this+ " at("+map.locationOf(this).x()+","+ map.locationOf(this).y()+ ") "+ "HEALTH :" +printHp()+ " Wallet $" + wallet);

		//check for the item that in the player inventory it is consumable if the item is a magical item (mushroom or star)
		for (Item item :this.getInventory()){
			MagicalItem magicalItem= MagicalItemManager.getInstance().getMagicalItem(item);
			if (magicalItem != null){
				actions.add(new ConsumeItemAction(magicalItem));
			}

		}
		if (!bottle.isEmpty()){
			actions.add(new DrinkWaterAction(bottle));
		}
		// Handle multi-turn Actions
		if (lastAction.getNextAction() != null)
			return lastAction.getNextAction();

		// return/print the console menu
		return menu.showMenu(this, actions, display);
	}

	/**
	 * Method to find the player display character (If Tall > M, else m)
	 *
	 * @return the display character of the player
	 */
	@Override
	public char getDisplayChar(){
		return this.hasCapability(PlayerStatus.TALL) ? Character.toUpperCase(super.getDisplayChar()): super.getDisplayChar();
	}

	/**
	 * Method to add the water from different fountain into the bottle
	 *
	 * @param water type of water
	 */
	public void addWater(Water water) {
		this.bottle.getWaters().push(water);
	}

	/**
	 * Method to deduct the player hp with conditions
	 *
	 * @param points number of hitpoints to deduct.
	 */
	@Override
	public void hurt(int points) {
		//if player is having status Tall (M), remove Tall and become back to normal (m)
		super.hurt(points);
		if (this.hasCapability(PlayerStatus.TALL)){
			this.removeCapability(PlayerStatus.TALL);
		}

	}

	/**
	 * Method to increase the player's attack
	 *
	 * @param damage damage that wants to be increase
	 */
	public void addDamage(int damage) {
		this.damage += damage;
	}

	@Override
	public IntrinsicWeapon getIntrinsicWeapon(){
		return new IntrinsicWeapon(damage, attack);
	}

	/**
	 * Method to increase wallet balance with the coins value picked up
	 *
	 * @param coins the value of coins to be added
	 * @return true after increase the balance
	 */
	@Override
	public boolean plusCoins(int coins) {
		boolean res = false;
		if (coins>=0){
			wallet +=coins;
			res = true;
		}
		return res;
	}

	/**
	 * Method to deduct wallet balance with the coins needed if enough
	 *
	 * @param coins the value of coins to be subtracted
	 * @return true after deducted the balance
	 */
	@Override
	public boolean minusCoins(int coins) {
		boolean res = false;
		if (coins>=0){
			wallet -=coins;
			res = true;
		}
		return res;
	}

	/**
	 * Method to get the balance of the wallet
	 *
	 * @return the balance in the wallet
	 */
	@Override
	public int getCoins() {
		return wallet;
	}

	/**
	 * a method that register current instance to the PlayerManager.
	 * It allows to downcast an Actor to a Player and also quick access to all
	 * Player
	 *
	 */
	protected void addToPlayerManager(){
		PlayerManager.getInstance().appendPlayer(this);
	}

	/**
	 * Reset the player hp to max and remove all the buff on the player
	 * Override method from Resettable.
	 */
	@Override
	public void resetInstance() {
		this.resetMaxHp(this.getMaxHp());

		for(Enum<?> enumerator:this.capabilitiesList()){
			if(enumerator == PlayerStatus.POWER || enumerator == PlayerStatus.TALL){
				this.removeCapability(enumerator);
			}
		}
	}

	/**
	 * Reset the effect turns back to 10
	 */
	public void resetTurn(){
		turn = 10;
	}

	/**
	 * Getter for the pet Yoshi
	 *
	 * @return the yoshi
	 */
	public Yoshi getYoshi() {
		return yoshi;
	}

	/**
	 * Setter the pet Yoshi
	 *
	 * @param yoshi the pet yoshi
	 */
	public void setYoshi(Yoshi yoshi) {
		if(this.yoshi == null){
			this.yoshi = yoshi;
		}
	}

}
