package game.terrains;

import edu.monash.fit2099.engine.positions.Location;
import game.enemies.Goomba;

import java.util.Random;

/**
 * <h1>Sprout</h1>
 * A class that represents one of a tree, Sprout.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Tree
 */
public class Sprout extends Tree {

    /**
     * Random number generator
     */
    private Random random = new Random();

    /**
     * Chances of Goomba spawn around it
     */
    private int spawnGoombaChance = 10;

    /**
     * The turn of sprout has been spawn for tick purpose
     */
    private int turns;

    /**
     * Constructor for Sprout class and initialise the turn with 0 when spawn
     */
    public Sprout() {
        super('+',90,10);
        turns = 0;
    }

    /**
     * Constructor for Sprout class and initialise the turn with 0 when spawn
     * @param location the location of sprout spawn
     */
    public Sprout(Location location) {
        super('+',90,10, location);
        turns = 0;
    }

    /**
     * A method to check in every round with what should do to the sprout
     *
     * @param location the location of sprout
     */
    public void tick(Location location) {
        turns += 1;

        // chances to spawn Goomba
        if (random.nextInt(100) <= spawnGoombaChance && !location.containsAnActor()) {
            location.addActor(new Goomba(location));
        }

        // after 10 turns, sprout will grow into sapling
        if (turns == 10){
            location.setGround(new Sapling(location));
        }

        super.tick(location);


    }

    /**
     * A to string method
     *
     * @return String of Sprout
     */
    @Override
    public String toString() {
        return "Sprout";
    }
}
