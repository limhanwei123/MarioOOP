package game.terrains;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.TeleportAction;
import game.enums.EnemyStatus;
import game.interfaces.Resettable;
import game.managers.WarpPipeManager;
import game.enemies.PiranhaPlant;
import game.enums.PlayerStatus;

import java.util.ArrayList;
import java.util.Random;

/**
 * <h1>Warp Pipe</h1>
 * A class that represents the Warp Pipe.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 20/5/2022
 *  @see TallTerrain
 */
public class WarpPipe extends TallTerrain implements Resettable {

    /**
     * Random number generator
     */
    private Random random = new Random();

    /**
     * Location of the place want to be teleporting
     */
    protected Location moveToLocation;

    /**
     * Map to be teleporting
     */
    protected String direction;

    /**
     * Whether a piranha plant is spawn above
     */
    protected boolean piranhaSpawn = false;

    /**
     * Last location the player on
     */
    protected Location previousLocation;

    /**
     * Current location of the player on
     */
    private Location currentLocation;

    /**
     * Constructor
     * @param moveToLocation location of the place want to be teleporting
     * @param direction map to be teleporting
     */
    public WarpPipe(Location moveToLocation, String direction) {
        super('C',100,0);
        this.moveToLocation = moveToLocation;
        this.direction = direction;
        this.addToWarpPipeManager();
        this.registerInstance();
    }

    /**
     * Method that check the allowable actions for the Warp Pipe
     *
     * @param actor the Actor acting
     * @param location the current Location
     * @param direction the direction of the Ground from the Actor
     * @return the action list can be done
     */
    @Override
    public ActionList allowableActions(Actor actor, Location location, String direction){
        ActionList action = super.allowableActions(actor,location,direction);
        if (location.containsAnActor()){
            action.add(new TeleportAction(this));
        }
        return action;
    }

    /**
     * A method to check in every round with what should do to the warp pipe
     *
     * @param location The location of the Ground
     */
    @Override
    public void tick(Location location){
        if (currentLocation == null){
        this.currentLocation = location;
        }
        if (!piranhaSpawn){
            location.addActor(new PiranhaPlant(location));
            piranhaSpawn = true;
        }
    }

    /**
     * Method to add the warp pipe into the WarpPipeManager class instance
     */
    protected void addToWarpPipeManager(){
        WarpPipeManager.getInstance().appendWarpPipe(this);
    }

    /**
     * Method to perform when player wants to reset the game (Spawn Piranha)
     */
    @Override
    public void resetInstance() {
        // if the player is on the warp pipe, it will randomly push the player away and spawn new piranha on it
        if (currentLocation.containsAnActor()){
            Actor actor = currentLocation.getActor();
            // check is player or not
            if (!actor.hasCapability(EnemyStatus.PIRANHA)){
                ArrayList<Location> moveActorLocation = new ArrayList<>();
                // find location around player
                for (Exit destination : currentLocation.getExits()){
                    if (!destination.getDestination().containsAnActor()){
                        moveActorLocation.add(destination.getDestination());
                    }
                }
                // move player to random place around him
                int randomIndex = random.nextInt(moveActorLocation.size());
                Location randomDestination = moveActorLocation.get(randomIndex);

                randomDestination.map().moveActor(actor,randomDestination);
                // spawn new piranha plant
                currentLocation.addActor(new PiranhaPlant(currentLocation));

            }
        }
        // else straight spawn piranha
        else{
            currentLocation.addActor(new PiranhaPlant(currentLocation));
        }
    }

    /**
     * Getter to get the direction
     *
     * @return the direction
     */
    public String getDirection() {
        return direction;
    }

    /**
     * Setter to set the previous location
     *
     * @param previousLocation the previous location of player on
     */
    public void setPreviousLocation(Location previousLocation) {
        this.previousLocation = previousLocation;
    }

    /**
     * Getter to get the teleporting location
     *
     * @return the location wanted to teleport
     */
    public Location getMoveToLocation() {
        return moveToLocation;
    }

    /**
     * Getter for the previous location
     *
     * @return the previous location of player on
     */
    public Location getPreviousLocation() {
        return previousLocation;
    }

    /**
     * ToString method
     *
     * @return Warp Pipe
     */
    @Override
    public String toString() {
        return "Warp Pipe";
    }
}
