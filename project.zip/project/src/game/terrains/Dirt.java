package game.terrains;

import edu.monash.fit2099.engine.positions.Ground;
import game.enums.GroundStatus;

/**
 * A class that represents bare dirt.
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 * @see Ground
 */
public class Dirt extends Ground {

	/**
	 * Constructor for Dirt class
	 * @see Ground
	 */
	public Dirt() {
		super('.');
		this.addCapability(GroundStatus.FERTILE);
	}
}
