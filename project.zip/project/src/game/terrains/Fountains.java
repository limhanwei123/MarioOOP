package game.terrains;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;

/**
 * <h1>Fountain</h1>
 * An abstract class of the fountain in game.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 20/5/2022
 *  @see Ground
 */
public abstract class Fountains extends Ground {
    /**
     * Constructor.
     *
     * @param displayChar character to display for this type of terrain
     */
    public Fountains(char displayChar) {
        super(displayChar);
    }

    /**
     * Method to check the actor can enter the fountain or not
     *
     * @param actor the Actor to check
     * @return
     */
    public boolean canActorEnter(Actor actor){
        return true;
    }
}
