package game.terrains;

import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.enemies.FlyingKoopa;
import game.enemies.Koopa;
import game.enums.GroundStatus;

import java.util.ArrayList;
import java.util.Random;


/**
 * <h1>Mature</h1>
 * A class that represents one of a tree, Mature.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Tree
 */
public class Mature extends Tree {

    /**
     * Random number generator
     */
    private Random random = new Random();

    /**
     * Chances of Koopa spawn around it
     */
    private int spawnKoopaChance = 15;

    /**
     * Chances of Mature turn back to dirt
     */
    private int turnDirtChance = 20;

    /**
     * The turn of mature has been spawn for tick purpose
     */
    private int turns;

    /**
     * Constructor for Mature class and initialise the turn with 0 when spawn
     * @see Ground
     */
    public Mature() {
        super('T',70,30);
        turns = 0;
    }

    /**
     * Constructor for Mature class and initialise the turn with 0 when spawn
     * @param location the location of mature spawn
     */
    public Mature(Location location) {
        super('T',70,30, location);
        turns = 0;
    }

    /**
     * A method to check in every round with what should do to the mature
     *
     * @param location the location of mature
     */
    public void tick(Location location) {
        turns += 1;

        // mature will have chances to spawn Koopa
        if (random.nextInt(100) <= spawnKoopaChance && !location.containsAnActor()) {
            int choice = random.nextInt(2);
            if (choice == 0){
                location.addActor(new Koopa(location));
            }
            else{
                location.addActor(new FlyingKoopa(location));
            }
        }

        // for every 5 round mature will spawn new sprout randomly around it
        if (turns % 5 == 0) {
            ArrayList<Location> dirts = new ArrayList<>();
            for (Exit exit : location.getExits()) {
                Location destination = exit.getDestination();
                if (destination.getGround().hasCapability(GroundStatus.FERTILE) && !destination.containsAnActor()) {
                    dirts.add(destination);
                }
            }
            if (!dirts.isEmpty()) {
                int randomIndex = random.nextInt(dirts.size());
                Location randomDestination = dirts.get(randomIndex);
                randomDestination.setGround(new Sprout(randomDestination));
            }
        }

        super.tick(location);

        // chance to die and become back to dirt
        if (random.nextInt(100) <= turnDirtChance) {
            location.setGround(new Dirt());
        }

    }

    /**
     * A to string method
     *
     * @return String of Mature
     */
    @Override
    public String toString() {
        return "Mature";
    }
}
