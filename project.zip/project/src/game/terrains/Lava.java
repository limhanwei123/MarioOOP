package game.terrains;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.enums.PlayerStatus;

/**
 * <h1>Lava</h1>
 * A class that represents the Lava in second map.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 20/5/2022
 *  @see Ground
 */
public class Lava extends Ground {
    /**
     * Constructor.
     *
     */
    public Lava() {
        super('L');
    }

    /**
     * Method to check whether the actor can enter it
     *
     * @param actor the Actor to check
     * @return true or false
     */
    public boolean canActorEnter(Actor actor){
        if (actor.hasCapability(PlayerStatus.PLAYER)){
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * A method to deduct any actor hp by 20 if the actor stand on it in every turn
     *
     * @param location The location of the Ground
     */
    public void tick(Location location){
        Actor actor = location.getActor();
        if (location.containsAnActor() && actor.hasCapability(PlayerStatus.PLAYER)){
            actor.hurt(15);
        }
    }

}
