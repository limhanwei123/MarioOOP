package game.terrains;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Location;
import game.Player;
import game.actions.RefillAction;
import game.enums.PlayerStatus;
import game.items.HealingWater;
import game.managers.PlayerManager;

/**
 * <h1>Health Fountain</h1>
 * A class that represents one of the fountain, Health Fountain.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 20/5/2022
 *  @see Fountains
 */
public class HealthFountain extends Fountains{

    /**
     * Constructor.
     */
    public HealthFountain() {
        super('H');
    }

    /**
     * Method that check the allowable actions for the Health Fountain
     *
     * @param actor the Actor acting
     * @param location the current Location
     * @param direction the direction of the Ground from the Actor
     * @return the action list can be done
     */
    @Override
    public ActionList allowableActions(Actor actor, Location location, String direction) {
        ActionList action = new ActionList();

        // When player near it, player can refill the bottle with healing water
        if (location.containsAnActor() && actor.hasCapability(PlayerStatus.PLAYER)){
            if (PlayerManager.getInstance().getPlayers().contains(actor)) {
                Player player = PlayerManager.getInstance().getPlayer(actor);
                action.add(new RefillAction(new HealingWater(player)));
            }
        }
        return action;
    }

    /**
     * ToString method
     *
     * @return Healing Fountain
     */
    public String toString(){
        return "Healing Fountain";
    }

}
