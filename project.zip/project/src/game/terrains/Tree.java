package game.terrains;

import edu.monash.fit2099.engine.positions.Location;
import game.interfaces.Resettable;
import java.util.Random;

/**
 * <h1>Tree</h1>
 * An abstract class that represents the tree in this game.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see TallTerrain
 */
public abstract class Tree extends TallTerrain implements Resettable {

    /**
     * Random number generator
     */
    private Random random = new Random();

    /**
     * Chances of reset back to dirt
     */
    private int chances = 50;

    /**
     * location of Tree spawn
     */
    private Location spawnLocation;

    /**
     * Constructor and register it as a reset instance
     *
     * @param displayChar the character that display in game
     * @param jumpChance the jump chance that the actor can jump over
     * @param fallDamage the fall damage if jump is unsuccessful
     */
    public Tree(char displayChar, int jumpChance, int fallDamage) {
        super(displayChar, jumpChance, fallDamage);
        this.registerInstance();
    }

    /**
     * Constructor with location and register it as a reset instance
     *
     * @param displayChar the character that display in game
     * @param jumpChance the jump chance that the actor can jump over
     * @param fallDamage the fall damage if jump is unsuccessful
     * @param location the location of tree spawn
     */
    public Tree(char displayChar, int jumpChance, int fallDamage, Location location) {
        super(displayChar, jumpChance, fallDamage);
        this.spawnLocation = location;
        this.registerInstance();

    }

    /**
     * Method to reset the tree back to dirt with 50% of chance
     */
    @Override
    public void resetInstance(){
        if (spawnLocation != null){
            if (random.nextInt(100) <= chances) {
                spawnLocation.setGround(new Dirt());
            }
        }
    }

    /**
     * A method that check for every turn when the game is ongoing and update the location every turn
     *
     * @param location The location of the Ground
     */
    @Override
    public void tick(Location location) {
        super.tick(location);
        this.spawnLocation = location;
    }
}
