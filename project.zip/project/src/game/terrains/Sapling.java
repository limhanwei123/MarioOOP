package game.terrains;

import edu.monash.fit2099.engine.positions.Location;
import game.items.Coins;

import java.util.Random;

/**
 * <h1>Sapling</h1>
 * A class that represents one of a tree, Sapling.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Tree
 */
public class Sapling extends Tree {

    /**
     * Random number generator
     */
    private Random random = new Random();

    /**
     * Chances of coin spawn on it
     */
    private int spawnCoinChance = 10;

    /**
     * The turn of sapling has been spawn for tick purpose
     */
    private int turns;

    /**
     * Constructor for Sapling class and initialise the turn with 0 when spawn
     */
    public Sapling(){
        super('t',80,20);
        turns = 0;
    }

    /**
     * Constructor for Sapling class and initialise the turn with 0 when spawn
     * @param location the location of sapling spawn
     */
    public Sapling(Location location) {
        super('t',80,20, location);
        turns = 0;
    }

    /**
     * A method to check in every round with what should do to the sapling
     *
     * @param location the location of sapling
     */
    public void tick(Location location) {
        turns += 1;

        // chances to spawn a coin on the sapling
        if (random.nextInt(100) <= spawnCoinChance) {
            location.addItem(new Coins(20, location));
        }

        // after 10 turns the sapling will grow into mature
        if (turns == 10){
            location.setGround(new Mature(location));
        }

        super.tick(location);

    }

    /**
     * A to string method
     *
     * @return String of Sapling
     */
    @Override
    public String toString() {
        return "Sapling";
    }
}

