package game.terrains;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import game.enums.*;


/**
 * <h1>Floor</h1>
 * A class that represents the floor inside a building.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Ground
 */
public class Floor extends Ground {
	/**
	 * Constructor for Floor class
	 * @see Ground
	 */
	public Floor() {
		super('_');
	}

	/**
	 *
	 * @param actor the Actor to check
	 * @return if the actor is having the status of can enter floor
	 */
	@Override
	public boolean canActorEnter(Actor actor) {
		return actor.hasCapability(PlayerStatus.CAN_ENTER_FLOOR);
	}
}
