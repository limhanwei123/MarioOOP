package game.terrains;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.JumpAction;
import game.enums.EnemyStatus;
import game.enums.PlayerStatus;
import game.items.Coins;

import java.util.Random;

/**
 * <h1>TallTerrain</h1>
 * An abstract class that represents a ground that need to be jump.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Ground
 */
public abstract class TallTerrain extends Ground{

    /**
     * Random number generator
     */
    private Random random = new Random();

    /**
     * Chances of actor to jump on it
     */
    private int jumpChance ;

    /**
     * The damage that hurt the player if jump is unsuccessful
     */
    private int fallDamage ;

    /**
     * Constructor that also initialise the jump success rate and fall damage if fail to jump
     *
     * @param displayChar
     * @param jumpChance
     * @param fallDamage
     */
    public TallTerrain(char displayChar, int jumpChance, int fallDamage) {
        super(displayChar);
        this.jumpChance = jumpChance;
        this.fallDamage = fallDamage;
    }

    /**
     * Check the actor can enter the tall terrain or not
     *
     * @param actor the Actor to check
     * @return true or false
     */
    public boolean canActorEnter(Actor actor){
        if (actor.hasCapability(PlayerStatus.POWER) || actor.hasCapability(EnemyStatus.FLY) || actor.hasCapability(PlayerStatus.ALLIES)){
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * When encounter a tall terrain, the player will jump with a chance
     *
     * @param by the player
     * @param at the location of player will jump to
     * @param map the map of the game
     * @return String of successful jump or unsuccessful jump
     */
    public String jump(Actor by, Location at, GameMap map) {
        Actor actor = by;
        // if successful jump then move the actor to the destination location
        if (random.nextInt(100) <= jumpChance || by.hasCapability(PlayerStatus.TALL)) {
            map.moveActor(by, at);
            return actor + " jumps successfully!";
        }
        // else deduct the player hp and stay at same place
        else {
            by.hurt(fallDamage);
            return actor + " fails and got hurt "+ fallDamage + " hp lost.";
        }
    }

    /**
     * This is a method that add all the action that can be done by TallTerrain when player nears it
     *
     * @param actor the Actor acting
     * @param location the current Location
     * @param direction the direction of the Ground from the Actor
     * @return list of actions
     */
    public ActionList allowableActions(Actor actor, Location location, String direction) {
        ActionList action = new ActionList();
        //if the player have no status from super mushroom and power star only the jump is available
        if (!location.containsAnActor() && !actor.hasCapability(PlayerStatus.POWER)){
            action.add(new JumpAction(this, location, direction));
        }
        return action;
    }

    /**
     * A method that check for every turn when the game is ongoing
     *
     * @param location The location of the Ground
     */
    @Override
    public void tick(Location location) {
        //if player is stand on the tall terrain
        if (location.getActor() != null) {
            //if player is having power star effect then break the tall terrain and drop $5 coin
            if (location.getActor().hasCapability(PlayerStatus.POWER)) {
                location.setGround(new Dirt());
                Coins coins = new Coins(5, location);
                location.addItem(coins);
            }
        }
    }
}
