package game.terrains;


/**
 * <h1>Wall</h1>
 * A class that represents the wall in this game.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see TallTerrain
 */
public class Wall extends TallTerrain {

	/**
	 * Constructor for Wall class
	 */
	public Wall() {
		super('#',80,20);
	}

	/**
	 * An override method to set the wall can block thrown objects
	 * @return true
	 */
	@Override
	public boolean blocksThrownObjects() {
		return true;
	}

	/**
	 * A to string method
	 *
	 * @return String of Wall
	 */
	@Override
	public String toString() {
		return "Wall";
	}
}
