package game.npcs;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actions.TalkingAction;
import game.actions.TradeAction;
import game.enums.PlayerStatus;
import game.items.PowerStar;
import game.items.SuperMushroom;
import game.weapons.Wrench;


/**
 * <h1>Toad</h1>
 * A class that represents the toad npc.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see Actor
 */
public class Toad extends Actor {
    /**
     * Constructor.
     *
     * @param name        the name of the Actor
     * @param displayChar the character that will represent the Actor in the display
     * @param hitPoints   the Actor's starting hit points
     */
    public Toad(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints);
        this.addCapability(PlayerStatus.TRADE_WITH_TOAD);
    }

    /**
     * Method to let the Toad stand still and do nothing for every turn
     *
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return do nothing action
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        return new DoNothingAction();
    }

    /**
     * This is a method that add all the action that can be done by Toad when player nears him
     *
     * @param otherActor the Actor that might perform an action.
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return list of actions
     */
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        //Create new action list and all the item that can be trade
        ActionList actions = new ActionList();
        Wrench wrench = new Wrench();
        PowerStar powerStar = new PowerStar();
        SuperMushroom superMushroom = new SuperMushroom();

        //add the trade action with the item, and the price to the toad action list
        actions.add(new TradeAction(wrench, wrench.getPrice()));
        actions.add(new TradeAction(superMushroom, superMushroom.getPrice()));
        actions.add(new TradeAction(powerStar, powerStar.getPrice()));

        actions.add(new TalkingAction());
        //add the talk action to toad
        return actions;
    }
}
