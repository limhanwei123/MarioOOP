package game.weapons;

import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.enums.PlayerStatus;
import game.interfaces.TradableItem;

/**
 * <h1>Wrench</h1>
 * A class that represents a weapon used by player, wrench.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 30/4/2022
 *  @see WeaponItem
 */
public class Wrench extends WeaponItem implements TradableItem {

    /**
     * price of the wrench
     */
    private int price;

    /**
     * Constructor.
     * adding the capability that can break shell and also price for trading of this item as $200
     *
     */
    public Wrench() {
        super("Wrench", 'w', 50, "knock", 80);
        this.addCapability(PlayerStatus.BREAK_SHELL);
        this.price = 200;
    }

    /**
     * Method to return the price of wrench
     *
     * @return price of wrench
     */
    @Override
    public int getPrice() {
        return this.price;
    }
}
