package game.weapons;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.DropItemAction;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.enums.WeaponStatus;
import game.items.MagicalItem;

/**
 * <h1>FireBow</h1>
 * A type of Weapon in the game.
 *
 *  @author Yishen Wong, Dion Chin, Lim Han Wei
 *  @version 1.0
 *  @since 22/5/2022
 *  @see game.actions.FireBowAction
 */
public class FireBow extends WeaponItem {
    /**
     * Constructor.
     */
    public FireBow() {
        super("FireBow",')',30,"shoots",70);
        addCapability(WeaponStatus.RANGE_ATTACK);
    }

    /**
     * Special Action that disallow Actors to drop this weapon.
     * @param actor The actor performing the action
     * @return null to disallow actor from dropping this weapon
     */
    @Override
    public DropItemAction getDropAction(Actor actor) {
        return null;
    }


}
